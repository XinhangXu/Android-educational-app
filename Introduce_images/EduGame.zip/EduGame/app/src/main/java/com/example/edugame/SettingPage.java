package com.example.edugame;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

public class SettingPage extends AppCompatActivity {

    Button bt01, bt02, bt03, btYellow, btGreen, btEasy, btNormal, btDifficult, btLife5, btLife10, btLife15, btFunctionTest, btDefaultColor;
    Switch switch_music;

    LinearLayout myLayout;
    //MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_page);

        GlobalClass globalClass = (GlobalClass) getApplicationContext();


        bt01 = findViewById(R.id.bt01);
        bt02 = findViewById(R.id.bt02);
        bt03 = findViewById(R.id.bt03);
        switch_music = findViewById(R.id.switch_music);
        btYellow = findViewById(R.id.btYellow);
        btGreen = findViewById(R.id.btGreen);
        btEasy = findViewById(R.id.btEasy);
        btNormal = findViewById(R.id.btNormal);
        btDifficult = findViewById(R.id.btDifficult);
        btLife5 = findViewById(R.id.btLife5);
        btLife10 = findViewById(R.id.btLife10);
        btLife15 = findViewById(R.id.btLife15);
        btFunctionTest = findViewById(R.id.btFunctionTest);
        myLayout = findViewById(R.id.layout_setting);
        btDefaultColor = findViewById(R.id.btDefaultColor);

/*        player = MediaPlayer.create(this, R.raw.bg_music);
        player.setLooping(true);
        if(globalClass.getIndex_music() == 1){
            player.start();
        }*/

        btYellow.setOnClickListener((v)->{
            myLayout.setBackgroundColor(Color.YELLOW);
            globalClass.setIndex_bgColor(1);
        });
        btGreen.setOnClickListener((v)->{
            myLayout.setBackgroundColor(Color.GREEN);
            globalClass.setIndex_bgColor(2);
        });
        btDefaultColor.setOnClickListener((v)->{
            myLayout.setBackgroundColor(Color.WHITE);
            globalClass.setIndex_bgColor(0);
        });


        bt01.setOnClickListener((v)->{
            globalClass.setIndex_player_character(1);
            Toast toast=Toast. makeText(getApplicationContext(),"Select Pysduck Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });
        bt02.setOnClickListener((v)->{
            globalClass.setIndex_player_character(2);
            Toast toast=Toast. makeText(getApplicationContext(),"Select Vulpix Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });
        bt03.setOnClickListener((v)->{
            globalClass.setIndex_player_character(3);
            Toast toast=Toast. makeText(getApplicationContext(),"Select Pikachu Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });

        btEasy.setOnClickListener((v)->{
            globalClass.setGlobal_speedDiff(1);
            Toast toast=Toast. makeText(getApplicationContext(),"Select 'EASY' Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });
        btNormal.setOnClickListener((v)->{
            globalClass.setGlobal_speedDiff(2);
            Toast toast=Toast. makeText(getApplicationContext(),"Select 'Normal' Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });
        btDifficult.setOnClickListener((v)->{
            globalClass.setGlobal_speedDiff(3);
            Toast toast=Toast. makeText(getApplicationContext(),"Select 'Difficult' Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });

        btLife5.setOnClickListener((v)->{
            globalClass.setLife_times(5);
            Toast toast=Toast. makeText(getApplicationContext(),"Set Life 5 Times Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });
        btLife10.setOnClickListener((v)->{
            globalClass.setLife_times(10);
            Toast toast=Toast. makeText(getApplicationContext(),"Set Life 10 Times Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });
        btLife15.setOnClickListener((v)->{
            globalClass.setLife_times(15);
            Toast toast=Toast. makeText(getApplicationContext(),"Set Life 15 Times Successfully",Toast. LENGTH_SHORT);
            toast.show();
        });

        btFunctionTest.setOnClickListener((v)->{ // for testing 'save record' function, click it, top5 will not be null, then have to go to'NoRecord'
            globalClass.testNotTop5();
        });


        /*switch_music.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    globalClass.setIndex_music(1);
                    //globalClass.manageMusic();
                    //player.start();
                } else {
                    // The toggle is disabled
                    globalClass.setIndex_music(0);
                    //globalClass.manageMusic();
                    //player.stop();
                }
            }
        });*/


    }


/*    @Override
    protected void onPause(){
        super.onPause();
        player.release();
        finish();
    }*/

}
