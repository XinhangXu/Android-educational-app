package com.example.edugame;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class PlayGame extends AppCompatActivity {

    ImageButton btRight, btLeft;
    ImageView player_view;
    TextView num01, num02, num03, num04, num05, txtNum, txtChance, txtCorrect;
    int targetNum, max=200, min=80;
    float[] curr_position = new float[6];//curr_position[0] not use, 1 to 5 is for five textView
    float player_position=0;
    int n1, n2, n3, n4, n5;// generate random number in textView
    int speedDiff;
    int count=0; // count how many times do the Thread loop
    int player_chance;
    int correct_times = 0;
    int cur_sum = 0;
    int index_checkNumber = 0; // 1 means satisfy the condition of 'if', 0 means not
    Button btStart,btCatch;
    Thread t;
    LinearLayout myLayout01,layout_character;
    MediaPlayer player;
    int index_catch=0;

    ObjectAnimator objectanimator1,objectanimator2,objectanimator3,objectanimator4,objectanimator5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_game);

        GlobalClass globalClass = (GlobalClass) getApplicationContext();

        player = MediaPlayer.create(this, R.raw.bg_music);
        player.setLooping(true);
        if(globalClass.getIndex_music() == 1){
            player.start();
        }

        btLeft = findViewById(R.id.btLeft);
        btRight = findViewById(R.id.btRight);
        player_view = findViewById(R.id.player_view);
        num01 = findViewById(R.id.num01);
        num02 = findViewById(R.id.num02);
        num03 = findViewById(R.id.num03);
        num04 = findViewById(R.id.num04);
        num05 = findViewById(R.id.num05);
        txtNum = findViewById(R.id.txtNum);
        btStart = findViewById(R.id.btStart);
        btCatch = findViewById(R.id.btCatch);
        txtChance = findViewById(R.id.txtChance);
        txtCorrect = findViewById(R.id.txtCorrect);
        myLayout01 = findViewById(R.id.layout01);
        layout_character = findViewById(R.id.layout_character);

        if(globalClass.getIndex_player_character() == 1){
            player_view.setImageResource(R.drawable.character01);
        }
        if(globalClass.getIndex_player_character() == 2){
            player_view.setImageResource(R.drawable.character02);
        }
        if(globalClass.getIndex_player_character() == 3){
            player_view.setImageResource(R.drawable.character03);
        }

        if(globalClass.getGlobal_speedDiff() == 1){
            speedDiff=-10000;
        }
        if(globalClass.getGlobal_speedDiff() == 2){
            speedDiff=-1000;
        }
        if(globalClass.getGlobal_speedDiff() == 3){
            speedDiff=0;
        }
        if(globalClass.getLife_times() == 5){
            player_chance = 5;
            txtChance.setText(String.valueOf(player_chance));
        }
        if(globalClass.getLife_times() == 10){
            player_chance = 10;
            txtChance.setText(String.valueOf(player_chance));
        }
        if(globalClass.getLife_times() == 15){
            player_chance = 15;
            txtChance.setText(String.valueOf(player_chance));
        }
        if(globalClass.getIndex_bgColor() == 1){
            myLayout01.setBackgroundColor(Color.YELLOW);
            layout_character.setBackgroundColor(Color.YELLOW);
        }
        if(globalClass.getIndex_bgColor() == 2){
            myLayout01.setBackgroundColor(Color.GREEN);
            layout_character.setBackgroundColor(Color.GREEN);
        }


        objectanimator1 = ObjectAnimator.ofFloat(num01,"y",1250);
        objectanimator2 = ObjectAnimator.ofFloat(num02,"y",1250);
        objectanimator3 = ObjectAnimator.ofFloat(num03,"y",1250);
        objectanimator4 = ObjectAnimator.ofFloat(num04,"y",1250);
        objectanimator5 = ObjectAnimator.ofFloat(num05,"y",1250);

/*        String str_correct = String.valueOf(correct_times);
        txtCorrect.setText(str_correct);*/

        btCatch.setOnClickListener((v)->{
            index_catch = 1;
        });

        btStart.setOnClickListener((v -> {
            if(player_chance > 0){

                setNumbers();
                objectanimator1.start();
                objectanimator2.start();
                objectanimator3.start();
                objectanimator4.start();
                objectanimator5.start();
                inistialiseValuables();
                continueCheckPosition();

            }else{
                globalClass.setGlobal_currentScore(correct_times);
                correct_times = 0;

                // check if current score is in top5 or nor
                if(String.valueOf(globalClass.getRankList()[4][0]).equals("null")){
                    Intent intent = new Intent(PlayGame.this, SaveRecord.class);
                    startActivity(intent);
                    finish();
                }else{
                    if(globalClass.getGlobal_currentScore() >= Integer.parseInt(String.valueOf(globalClass.getRankList()[4][1]))){ // compare with the smallest score, if true, go to saveRecord page
                        Intent intent = new Intent(PlayGame.this, SaveRecord.class);
                        startActivity(intent);
                        finish();
                    }else{ // not top5, noRecord page
                        Intent intent = new Intent(PlayGame.this, NoRecord.class);
                        startActivity(intent);
                        finish();
                    }
                }


                Toast toast=Toast. makeText(getApplicationContext(),"Game Over !!",Toast. LENGTH_LONG);
                toast.show();

            }
        }));


        btLeft.setOnClickListener((v)->{
            if(player_position >= -500 && player_position <= 500){
                player_position = player_position -40;
                player_view.setX(player_position);
            }else{
                Toast toast=Toast. makeText(getApplicationContext(),"Crash Border !!",Toast. LENGTH_SHORT);
                toast.show();
                player_position = 0;
                player_view.setX(player_position);
            }
        });
        btRight.setOnClickListener((v)->{
            if(player_position >= -500 && player_position <= 500){
                player_position = player_position +40;
                player_view.setX(player_position);
            }else{
                Toast toast=Toast. makeText(getApplicationContext(),"Crash Border !!",Toast. LENGTH_SHORT);
                toast.show();
                player_position = 0;
                player_view.setX(player_position);
            }
        });









    }

    public void setNumbers(){
        // randomly set different falling speed for every number
/*        while(count_speedDiff > 5){
            int curr_speed = new Random().nextInt((9 - 2) + 1) + 2;
            if(curr_speed != )
            count_speedDiff++;
        }*/


        int speed01=0, speed02=0, speed03=0, speed04=0, speed05=0;
        int speed_index = new Random().nextInt((5 - 1) + 1) + 1;
        //select speed01-05 in 2,3, 5, 7, 8
        if(speed_index == 1){
            speed01 = 2;
            speed02 = 4;
            speed03 = 6;
            speed04 = 8;
            speed05 = 10;

        }
        if(speed_index == 2){
            speed01 = 8;
            speed02 = 4;
            speed03 = 6;
            speed04 = 10;
            speed05 = 2;

        }
        if(speed_index == 3){
            speed01 = 2;
            speed02 = 10;
            speed03 = 8;
            speed04 = 6;
            speed05 = 4;

        }
        if(speed_index == 4){
            speed01 = 4;
            speed02 = 2;
            speed03 = 6;
            speed04 = 10;
            speed05 = 8;

        }
        if(speed_index == 5){
            speed01 = 6;
            speed02 = 8;
            speed03 = 2;
            speed04 = 10;
            speed05 = 4;

        }

        objectanimator1.setDuration(1000*speed01-speedDiff);
        objectanimator2.setDuration(1000*speed02-speedDiff);
        objectanimator3.setDuration(1000*speed03-speedDiff);
        objectanimator4.setDuration(1000*speed04-speedDiff);
        objectanimator5.setDuration(1000*speed05-speedDiff);

        //randomly generate different number and decide the position of the 2 correct answer.
        targetNum = new Random().nextInt((max - min) + 1) + min;
        String str_mynum = String.valueOf(targetNum).toString();
        txtNum.setText(str_mynum);

        int index01 = new Random().nextInt((7 - 1) + 1) + 1;
        if(index01 == 1){
            int mygap = new Random().nextInt((70 - 5) + 1) + 5;
            n1 = targetNum - mygap;
            n2 = mygap;
            n3 = new Random().nextInt((200 - 2) + 1) + 2;
            n4 = new Random().nextInt((200 - 2) + 1) + 2;
            n5 = new Random().nextInt((200 - 2) + 1) + 2;
        }
        if(index01 == 2){
            int mygap = new Random().nextInt((70 - 5) + 1) + 5;
            n1 = targetNum - mygap;
            n3 = mygap;
            n2 = new Random().nextInt((200 - 2) + 1) + 2;
            n4 = new Random().nextInt((200 - 2) + 1) + 2;
            n5 = new Random().nextInt((200 - 2) + 1) + 2;
        }
        if(index01 == 3){
            int mygap = new Random().nextInt((70 - 5) + 1) + 5;
            n1 = targetNum - mygap;
            n4 = mygap;
            n2 = new Random().nextInt((200 - 2) + 1) + 2;
            n3 = new Random().nextInt((200 - 2) + 1) + 2;
            n5 = new Random().nextInt((200 - 2) + 1) + 2;
        }
        if(index01 == 4){
            int mygap = new Random().nextInt((70 - 5) + 1) + 5;
            n2 = targetNum - mygap;
            n4 = mygap;
            n1 = new Random().nextInt((200 - 2) + 1) + 2;
            n3 = new Random().nextInt((200 - 2) + 1) + 2;
            n5 = new Random().nextInt((200 - 2) + 1) + 2;
        }
        if(index01 == 5){
            int mygap = new Random().nextInt((70 - 5) + 1) + 5;
            n2 = targetNum - mygap;
            n3 = mygap;
            n1 = new Random().nextInt((200 - 2) + 1) + 2;
            n4 = new Random().nextInt((200 - 2) + 1) + 2;
            n5 = new Random().nextInt((200 - 2) + 1) + 2;
        }
        if(index01 == 6){
            int mygap = new Random().nextInt((70 - 5) + 1) + 5;
            n4 = targetNum - mygap;
            n3 = mygap;
            n1 = new Random().nextInt((200 - 2) + 1) + 2;
            n2 = new Random().nextInt((200 - 2) + 1) + 2;
            n5 = new Random().nextInt((200 - 2) + 1) + 2;
        }
        if(index01 == 7){
            int mygap = new Random().nextInt((70 - 5) + 1) + 5;
            n4 = targetNum - mygap;
            n5 = mygap;
            n1 = new Random().nextInt((200 - 2) + 1) + 2;
            n2 = new Random().nextInt((200 - 2) + 1) + 2;
            n3 = new Random().nextInt((200 - 2) + 1) + 2;
        }

        //set number to textView
        String str_n1 = String.valueOf(n1).toString();
        num01.setText("  " + str_n1);
        String str_n2 = String.valueOf(n2).toString();
        num02.setText("  " + str_n2);
        String str_n3 = String.valueOf(n3).toString();
        num03.setText("  " + str_n3);
        String str_n4 = String.valueOf(n4).toString();
        num04.setText("  " + str_n4);
        String str_n5 = String.valueOf(n5).toString();
        num05.setText("  " + str_n5);

    }


    public void checkNumber(){
        if(index_catch == 1 && player_position >= -480 && player_position <= -360 ){//curr_position[1] < 1100 && curr_position[1] > 950
            cur_sum = cur_sum + n1;
            checkSum();
            //index_checkNumber = 1;
            Toast toast=Toast. makeText(getApplicationContext(),"catch "+ String.valueOf(n1),Toast. LENGTH_SHORT);
            toast.show();
            index_catch = 0;
        }
        if( index_catch == 1 && player_position >= -300 && player_position <= -160 ){//curr_position[2] < 1100 && curr_position[2] > 950
            cur_sum = cur_sum + n2;
            checkSum();
            //index_checkNumber = 1;
            Toast toast=Toast. makeText(getApplicationContext(),"catch "+ String.valueOf(n2),Toast. LENGTH_SHORT);
            toast.show();
            index_catch = 0;
        }
        if(index_catch == 1 && player_position >= -40 && player_position <= 40 ){//curr_position[3] < 1100 && curr_position[3] > 950
            cur_sum = cur_sum + n3;
            checkSum();
            //index_checkNumber = 1;
            Toast toast=Toast. makeText(getApplicationContext(),"catch "+ String.valueOf(n3),Toast. LENGTH_SHORT);
            toast.show();
            index_catch = 0;
        }
        if(index_catch == 1 && player_position >= 160 && player_position <= 300 ){//curr_position[4] < 1100 && curr_position[4] > 950
            cur_sum = cur_sum + n4;
            checkSum();
            //index_checkNumber = 1;
            Toast toast=Toast. makeText(getApplicationContext(),"catch "+ String.valueOf(n4),Toast. LENGTH_SHORT);
            toast.show();
            index_catch = 0;
        }
        if(index_catch == 1 && player_position <= 480 && player_position >= 360 ){//curr_position[5] < 1100 && curr_position[5] > 950
            cur_sum = cur_sum + n5;
            checkSum();
            //index_checkNumber = 1;
            Toast toast=Toast. makeText(getApplicationContext(),"catch "+ String.valueOf(n5),Toast. LENGTH_SHORT);
            toast.show();
            index_catch = 0;
        }
    }

    public void continueCheckPosition(){
        t = new Thread(){
            @Override
            public void run() {
                while(count < 60){
                    try{
                        Thread.sleep(500); // check position every 0.5s

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //curr_position[0] = player_view.getX();
                                curr_position[1] = num01.getY();
                                curr_position[2] = num02.getY();
                                curr_position[3] = num03.getY();
                                curr_position[4] = num04.getY();
                                curr_position[5] = num05.getY();

                                count++;
                                checkNumber();
                                //if(index_checkNumber == 1){ //check sum when 'checkNumber' condition is satisfied
                                    //checkSum();
                                    //index_checkNumber = 0;
                                //}
                            }
                        });
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }

                }

            }
        };
        t.start();

    }


    public void checkSum(){
        if(cur_sum == targetNum){
            correct_times++;
            txtCorrect.setText(String.valueOf(correct_times));
            Toast toast=Toast. makeText(getApplicationContext(),"Successful",Toast. LENGTH_LONG);
            toast.show();
        }/*else{
            Toast toast=Toast. makeText(getApplicationContext(),"Failed",Toast. LENGTH_LONG);
            toast.show();
        }*/
/*        Toast toast=Toast. makeText(getApplicationContext(),"check once",Toast. LENGTH_LONG);
        toast.show();*/
    }

    public void inistialiseValuables(){
        player_view.setX(0);
        player_position = 0;
        cur_sum = 0;
        count = 0;
        curr_position[1] = 0;
        curr_position[2] = 0;
        curr_position[3] = 0;
        curr_position[4] = 0;
        curr_position[5] = 0;
        player_chance = player_chance - 1;
        String str_chance = String.valueOf(player_chance).toString();
        txtChance.setText(str_chance);
    }

    protected void onPause(){
        super.onPause();
        player.release();
        finish();
    }








}
