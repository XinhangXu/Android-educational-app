package com.example.edugame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ImageButton;

public class HomeActivity extends AppCompatActivity {

    ImageButton btPlay, btSet, btRank;
    //MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        GlobalClass globalClass = (GlobalClass) getApplicationContext();

        btPlay = findViewById(R.id.btPlay);
        btSet = findViewById(R.id.btSet);
        btRank = findViewById(R.id.btRank);

        btPlay.setOnClickListener((v)->{
            Intent intent = new Intent(HomeActivity.this, PlayGame.class);
            startActivity(intent);
        });

        btSet.setOnClickListener((v)->{
            Intent intent = new Intent(HomeActivity.this, SettingPage.class);
            startActivity(intent);
        });

        btRank.setOnClickListener((v)->{
            Intent intent = new Intent(HomeActivity.this, RankPage.class);
            startActivity(intent);
        });


/*        player = MediaPlayer.create(this, R.raw.bg_music);
        player.setLooping(true);
        if(globalClass.getIndex_music() == 1){
            player.start();
        }*/


    }



/*    @Override
    protected void onPause(){
        super.onPause();
        player.release();
        finish();
    }*/


}
