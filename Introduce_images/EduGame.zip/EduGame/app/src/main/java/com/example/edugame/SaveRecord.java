package com.example.edugame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SaveRecord extends AppCompatActivity {

    Button btSave, btBack;
    EditText txtMyName;
    TextView txtMyScore, txtMyRank;
    //MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_record);

        GlobalClass globalClass = (GlobalClass) getApplicationContext();

/*        player = MediaPlayer.create(this, R.raw.bg_music);
        player.setLooping(true);
        if(globalClass.getIndex_music() == 1){
            player.start();
        }*/

        btSave = findViewById(R.id.btSave);
        txtMyRank = findViewById(R.id.txtMyRank);
        btBack = findViewById(R.id.btBack);
        txtMyName = findViewById(R.id.txtMyName);
        txtMyScore = findViewById(R.id.txtMyScore);

        txtMyScore.setText(String.valueOf(globalClass.getGlobal_currentScore()));//correct


        btSave.setOnClickListener((v)->{

            String name_input = String.valueOf(txtMyName.getText());

            for(int i = 0; i <5; i++){//check new record ranking position
                if(String.valueOf(globalClass.getRankList()[i][0]).equals("null")){
                    String str = String.valueOf(globalClass.getGlobal_currentScore());
                    globalClass.setRankList(i, txtMyName.getText().toString(), str);
                    txtMyRank.setText("top " + String.valueOf(i+1).toString());
                    Toast toast=Toast.makeText(getApplicationContext(),"'" + txtMyName.getText().toString() + "' Save Successfully",Toast. LENGTH_LONG);
                    toast.show();
                    break;
                }else{
                    if(globalClass.getGlobal_currentScore() >= Integer.parseInt(String.valueOf(globalClass.getRankList()[i][1]))){
                        String str = String.valueOf(globalClass.getGlobal_currentScore());
                        globalClass.setRankList(i, txtMyName.getText().toString(), str);
                        txtMyRank.setText("top " + String.valueOf(i+1).toString());
                        Toast toast=Toast.makeText(getApplicationContext(),"'" + txtMyName.getText().toString() + "' Save Successfully",Toast. LENGTH_LONG);
                        toast.show();
                        break;
                    }
                }
            }


        });


        btBack.setOnClickListener((v)->{
            Intent intent = new Intent(SaveRecord.this, HomeActivity.class);
            startActivity(intent);
            finish();
        });

    }

/*    protected void onPause(){
        super.onPause();
        player.release();
        finish();
    }*/
}
