package com.example.edugame;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.TextView;

public class RankPage extends AppCompatActivity {

    TextView txtName01, txtScore01, txtName02, txtScore02,txtName03, txtScore03,txtName04, txtScore04,txtName05, txtScore05;

    //MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank_page);

        GlobalClass globalClass = (GlobalClass) getApplicationContext();

/*        player = MediaPlayer.create(this, R.raw.bg_music);
        player.setLooping(true);
        if(globalClass.getIndex_music() == 1){
            player.start();
        }*/


        txtName01 = findViewById(R.id.txtName01);
        txtScore01 = findViewById(R.id.txtScore01);
        txtName02 = findViewById(R.id.txtName02);
        txtScore02 = findViewById(R.id.txtScore02);
        txtName03 = findViewById(R.id.txtName03);
        txtScore03 = findViewById(R.id.txtScore03);
        txtName04 = findViewById(R.id.txtName04);
        txtScore04 = findViewById(R.id.txtScore04);
        txtName05 = findViewById(R.id.txtName05);
        txtScore05 = findViewById(R.id.txtScore05);

        txtName01.setText(String.valueOf(globalClass.getRankList()[0][0]));
        txtScore01.setText(String.valueOf(globalClass.getRankList()[0][1]));
        txtName02.setText(String.valueOf(globalClass.getRankList()[1][0]));
        txtScore02.setText(String.valueOf(globalClass.getRankList()[1][1]));
        txtName03.setText(String.valueOf(globalClass.getRankList()[2][0]));
        txtScore03.setText(String.valueOf(globalClass.getRankList()[2][1]));
        txtName04.setText(String.valueOf(globalClass.getRankList()[3][0]));
        txtScore04.setText(String.valueOf(globalClass.getRankList()[3][1]));
        txtName05.setText(String.valueOf(globalClass.getRankList()[4][0]));
        txtScore05.setText(String.valueOf(globalClass.getRankList()[4][1]));



    }


/*    protected void onPause(){
        super.onPause();
        player.release();
        finish();
    }*/
}
