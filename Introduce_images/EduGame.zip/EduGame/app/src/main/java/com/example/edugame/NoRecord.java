package com.example.edugame;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.TextView;

public class NoRecord extends AppCompatActivity {

    TextView txtBadScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_record);

        GlobalClass globalClass = (GlobalClass) getApplicationContext();


        txtBadScore = findViewById(R.id.txtBadScore);
        txtBadScore.setText(String.valueOf(globalClass.getGlobal_currentScore()));

    }
}
