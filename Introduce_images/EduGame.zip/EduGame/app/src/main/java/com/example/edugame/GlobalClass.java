package com.example.edugame;

import android.app.Application;
import android.media.MediaPlayer;

import java.util.ArrayList;
import java.util.List;

public class GlobalClass extends Application {

    private int index_player_character=2;
    private int global_speedDiff=2;
    private int global_currentScore=0;
    private int life_times = 5;// store current score
    private String[][] rankList = new String[5][2]; // top5, [][0]name, [][1]score, 0->4 means top1 -> top5
    private int index_music = 1;
    private  int index_bgColor = 0; //1 yellow, 2 green, 0 default color
/*    private MediaPlayer player = MediaPlayer.create(this, R.raw.bg_music);

    public void manageMusic(){
        if(index_music == 1){
            player.start();
        }else{
            player.stop();
        }

    }*/

    public int getIndex_bgColor() {
        return index_bgColor;
    }

    public void setIndex_bgColor(int index_bgColor) {
        this.index_bgColor = index_bgColor;
    }

    public int getIndex_music() {
        return index_music;
    }

    public void setIndex_music(int index_music) {
        this.index_music = index_music;
    }

    public String[][] getRankList() {
        return rankList;
    }

    public void testNotTop5(){ //input str is rankList[index][0]
        rankList[0][0] = "AA";   rankList[0][1] = "9";
        rankList[1][0] = "BB";   rankList[1][1] = "8";
        rankList[2][0] = "CC";   rankList[2][1] = "7";
        rankList[3][0] = "DD";   rankList[3][1] = "6";
        rankList[4][0] = "EE";   rankList[4][1] = "5";

    }


    //@Override
    public void setRankList(int position, String myname, String myscore) {
        //this.rankList = rankList;
        rankList[position][0] = myname;
        rankList[position][1] = myscore;
    }

    public int getIndex_player_character() {
        return index_player_character;
    }

    public void setIndex_player_character(int index_player_character) {
        this.index_player_character = index_player_character;
    }

    public int getGlobal_speedDiff() {
        return global_speedDiff;
    }

    public void setGlobal_speedDiff(int global_speedDiff) {
        this.global_speedDiff = global_speedDiff;
    }

    public int getLife_times() {
        return life_times;
    }

    public void setLife_times(int life_times) {
        this.life_times = life_times;
    }


    public int getGlobal_currentScore() {
        return global_currentScore;
    }

    public void setGlobal_currentScore(int global_currentScore) {
        this.global_currentScore = global_currentScore;
    }

/*    public GlobalClass(int index_player_character, int global_speedDiff, int global_currentScore, int life_times, String[][] rankList, String lettest) {
        this.index_player_character = index_player_character;
        this.global_speedDiff = global_speedDiff;
        this.global_currentScore = global_currentScore;
        this.life_times = life_times;
        this.rankList = rankList;
        this.lettest = lettest;
    }*/
}
